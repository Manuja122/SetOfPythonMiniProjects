# Files-Sorter
This is python script that sort the files in Download directory to other directories depending on extention.
