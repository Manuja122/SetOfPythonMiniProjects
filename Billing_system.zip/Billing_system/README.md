<h1>Billing system using Tkinter</h1>
<p>This project can be used for any shops. User can store all the data and generate the bill.</p>

<h2>Tech stack:</h2>
<ul>
    <li>Python</li>
</ul>

<h2>Libraries used:</h2>
<ul>
    <li>Tkinter</li>
    <li>Os</li>
    <li>Messagebox</li>
</ul>

<h3>To install external modules:</h3>
<p><li>Run pip install tkinter</li></p>

<h3>To execute the project:</h3>
<p><li>Run billing system.py</li></p>

<h3>Screenshot/GIF of this project.</h3>

![Bill](https://user-images.githubusercontent.com/72568715/134779769-7695a727-adbb-43b7-9e60-1205dc982ae7.PNG)
