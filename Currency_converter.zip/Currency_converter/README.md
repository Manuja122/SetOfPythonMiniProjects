# Script Title
<!--Remove the below lines and add yours -->
A small python program that converts currency with live info

### Prerequisites
<!--Remove the below lines and add yours -->
- requests
- Python 3

### How to run the script
<!--Remove the below lines and add yours -->
> python cc.py

### Screenshot/GIF showing the sample use of the script
<!--Remove the below lines and add yours -->
![ ](https://github.com/Python-World/python-mini-projects/blob/master/projects/Currency_converter/output.png)

## *Author Name*
<!--Remove the below lines and add yours -->
[github-of-wone](https://github.com/github-of-wone/)
