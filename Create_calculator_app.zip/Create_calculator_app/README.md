# Script Title
<!--Remove the below lines and add yours -->
A small python program that creates a calculator app

### Prerequisites
<!--Remove the below lines and add yours -->
Python 3

### How to run the script
<!--Remove the below lines and add yours -->
> python calculator.py

### Screenshot/GIF showing the sample use of the script
<!--Remove the below lines and add yours -->
![Output](https://user-images.githubusercontent.com/53505850/95007683-0d85c700-0630-11eb-9aa4-7125f6be1ea0.PNG)


## *Author Name*
<!--Remove the below lines and add yours -->
[Gaodong](https://github.com/xlgd)
