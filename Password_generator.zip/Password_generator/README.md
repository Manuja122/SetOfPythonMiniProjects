# Password_generator

This script generate a random password

## Prerequisites

None

## How to run the script

    python password_generator.py

## Screenshot/GIF showing the sample use of the script

<img width="499" alt="screenshot" src="https://user-images.githubusercontent.com/92649530/138557429-aba58d64-fe29-4a1c-952c-428046de833e.png">

## Author Name
***lilo550***
