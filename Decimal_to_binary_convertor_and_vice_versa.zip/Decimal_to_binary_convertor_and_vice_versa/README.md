# Script Title
<!--Remove the below lines and add yours -->
A small python program that converts binary and decimal

### Prerequisites
<!--Remove the below lines and add yours -->
- Python 3

### How to run the script
<!--Remove the below lines and add yours -->
> python decimal_to_binary.py

### Screenshot/GIF showing the sample use of the script
<!--Remove the below lines and add yours -->
![ ](https://github.com/Python-World/python-mini-projects/blob/master/projects/Decimal_to_binary_convertor_and_vice_versa/output.png)

## *Author Name*
<!--Remove the below lines and add yours -->
[Alan Anaya](https://github.com/alananayaa/)
