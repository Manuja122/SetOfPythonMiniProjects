# Script Title

<!--Remove the below lines and add yours -->
Crawl the POI in the city through Baidu map API.

### Prerequisites
<!--Remove the below lines and add yours -->

1. `pip install -r requirements.txt`
2. Log in to [Baidu map open platform](https://lbsyun.baidu.com/apiconsole/key#/home), creating web API and record AK.

### How to run the script

<!--Remove the below lines and add yours -->

1. `cd python-mini-projects\projects\Baidu_POI_crawl`
2. `python main.py --ak yours_ak --city city_name --poi poi_name` 

### Screenshot/GIF showing the sample use of the script

<!--Remove the below lines and add yours -->

![image-20211117172514622](https://user-images.githubusercontent.com/71769312/142175449-294daf40-413a-43df-aa3a-8d99a203afa9.png)

![UXGOS$6WMD)`{XQ$8YK}7WU](https://user-images.githubusercontent.com/71769312/142175459-8f10d1c4-5c5d-4754-9fd5-d5ec58a79081.png)

## *Author Name*

<!--Remove the below lines and add yours -->
[YiZhou Chen](https://github.com/geoyee)
