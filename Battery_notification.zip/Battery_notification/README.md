# Battery Notificator

This python script gives you a notification about your battery percentage of the device.

## Pre-requisites:

You will need to install python on your machine. You can download python from the python.org and install it.
And a few other python package that you need to install are as:
 
    1. psutil
        > pip install psutil

    2. pynotifier
        > pip install py-notifier

    3. win10toast
        > pip install win10toast

## How to run the Script:
    python battery.py

## Authon Name:
Bharat Gupta
