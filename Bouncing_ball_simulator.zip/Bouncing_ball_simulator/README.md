# Bouncing ball simulator
<!--Remove the below lines and add yours -->
This script shows the simulation of few balls bouncing in a container under gravity.
They also collide with the bottom part and the walls of the container.

### Prerequisites
<!--Remove the below lines and add yours -->
The script runs in python3.
pygame module is needed

pip3 install requirements.txt

### How to run the script
<!--Remove the below lines and add yours -->
Navigate to the folder where the source code is written.
Open a terminal and execute the command:

python3 ball_bounce.py

## *Author Name*
<!--Remove the below lines and add yours -->
Ayush Shaw
