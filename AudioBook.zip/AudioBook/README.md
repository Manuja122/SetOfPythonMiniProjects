# AudioBook

### Description
This application will make an mp3 based on you pdf file.

### Instal the requirements
```
pip install gtts
pip install PyPDF2
```
### Dun the application
```
python Audio-book.py
```
