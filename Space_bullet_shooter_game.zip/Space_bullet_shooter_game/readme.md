## A Simple Space Bullet Shooter Game:
##### To be Played with a Computer.
* Arrows to move up and down and left and right.
* Enter to shoot a bullet.
  

### Example Game:
![Game](spacegame.png)
